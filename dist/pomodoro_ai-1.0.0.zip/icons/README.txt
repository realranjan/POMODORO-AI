Icon files for Pomodoro AI Chrome Extension

icon16.png - 16x16 pixels (toolbar icon)
icon48.png - 48x48 pixels (extension management page) 
icon128.png - 128x128 pixels (Chrome Web Store and install dialog)

These are simple tomato-themed icons representing the Pomodoro technique,
with an AI element represented by circuit/brain patterns.
